package main

import (
	"fmt"
	"redis_cli/gedis"
)

func main() {
	//ctx := context.Background()
	//ret := gedis.Redis().Get(ctx, "name")
	//v, err := ret.Result()
	//if err != nil {
	//	log.Fatal(err)
	//}
	//log.Println(v)

	//fmt.Println(gedis.NewStringOperation().Get("namew").Unwrap())
	//fmt.Println(gedis.NewStringOperation().Get("namew").Unwrap_Or("enqi"))
	//fmt.Println(gedis.NewStringOperation().MGet("name","age").Unwrap())
	iter := gedis.NewStringOperation().MGet("name","age","huhu").Iter()

	for iter.HasNext() {
		fmt.Println(iter.Next())
	}


}
