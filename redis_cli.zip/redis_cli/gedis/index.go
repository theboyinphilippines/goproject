package gedis

import (
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"log"
	"sync"
)

var redisclient *redis.Client
var redisClient_Once sync.Once

func Redis() *redis.Client {
	redisClient_Once.Do(func() {

		redisclient = redis.NewClient(&redis.Options{
			Addr:     "localhost:6379",
			Password: "", // no password set
			DB:       0,  // use default DB
			PoolSize: 15, // 连接池大小
		})

		_, err := redisclient.Ping(context.Background()).Result()
		if err != nil {
			log.Fatal(fmt.Errorf("redis connect err:%s", err))
		}

	})

	return redisclient

}
