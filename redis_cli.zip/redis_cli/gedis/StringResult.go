package gedis

type StringResult struct {
	Result string
	Err error
}

// 构造函数
func NewStringResult(result string, err error) *StringResult {
	return &StringResult{Result: result, Err: err}
}

// 返回值：有错误返回错误，没错误返回结果
func(this *StringResult) Unwrap() string{
	if this.Err != nil {
		panic(this.Err)
	}
	return this.Result
}

// 返回值：有错误返回一个默认传入值，没错误返回结果
func(this *StringResult) Unwrap_Or(str string) string{
	if this.Err != nil {
		return str
	}
	return this.Result
}