package gedis

import "context"


// 操作string类型

type StringOperation struct {

	ctx context.Context
}


// 构造函数
func NewStringOperation() *StringOperation {
	return &StringOperation{ctx: context.Background()}
}


func(this *StringOperation)Get(key string) *StringResult {

	return NewStringResult(Redis().Get(this.ctx,key).Result())

}

//获取多值
func(this *StringOperation)MGet(keys ...string) *SliceResult {

	return NewSliceResult(Redis().MGet(this.ctx,keys...).Result())

}
